from setuptools import setup, find_packages

setup(
    name="src", 
    version="0.0.1",
    description="It's a fashion Apparel Package",
    author="DeepranjanG",
    packages=find_packages(),
    licence="MIT"
)